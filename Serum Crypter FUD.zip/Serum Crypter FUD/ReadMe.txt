Hello!


CRITICAL READ THIS :
Make Sure You Have MSBuild Tools 2015, So You Can Use The Crypter, And Crypt Files!
MSBuild Tools Link : https://www.microsoft.com/en-us/download/details.aspx?id=48159

Tutorial How to Use Serum Crypter :


//Note If You See, Payload.exe, Don't Worry It is not Virus, It is Anti-Debugger, To Protect Our Crypter From Cracking/Decompiling

1.Run Serum Crypter.exe
2.Select Your File/Virus, It Will Convert It To Base64 And will display on TextBox, Press CTRL+A Copy All Base64 Code
3.Make New Txt on your desktop, Paste inside All Base64 Code
4.Go To Website, a.uguu.se or uguu.se,  Upload it There
5.Copy The .txt Direct Link, Paste It On Crypter Where it is says Link...
6.Then Press Crypt, you will see messages, if all is Good, just press ok, then ok, and continue, then it will take 1 -2 min, to crypt just wait!
7. you will see the cmd building, and Last, it will say, Build Done!, Have Good Day :)